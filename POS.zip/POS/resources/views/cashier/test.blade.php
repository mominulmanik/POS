@foreach($order as $order)

{{$order->quantity}}
{{$order->product_id}}
{{$order->p_quantity}}
@endforeach