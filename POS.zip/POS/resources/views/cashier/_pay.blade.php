<div class="modal-body">
    <div class="row">
        <div class="col-md-7">
            <table class="table">
                <thead>
                <tr>
                    <th>Description</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
                </thead>
                @if($order)
                    <tbody>
                    <?php $total = 0; 
                    //$i=0;
                    ?>
                    @foreach($order->order_details()->select(DB::raw("description,sum(quantity) as quantity,price,discount"))->groupBy('product_id')->groupBy('price')->groupBy('description')->groupBy('discount')->orderBy('description')->get() as $orderDetail)
                        <tr @if(!empty($orderDetail->deleted_at)) style="text-decoration: line-through;" @endif>
                            <td>
                                {{$orderDetail->description}}
                            </td>

                            <td>
                                {{$orderDetail->quantity}}
                            </td>
                            <td align="right">$ {{number_format($orderDetail->price,2)}}</td>
                            <td align="right">
                                $ {{number_format($orderDetail->price * $orderDetail->quantity,2)}}</td>
                        </tr>
                        <?php if (empty($orderDetail->deleted_at)) $total += ($orderDetail->price * $orderDetail->quantity ); ?>
                    @endforeach
                    </tbody>
                @endif
            </table>
            @if($order)
                <div style="text-align: right;float: right;border-top: solid 1px whitesmoke;">
                    <table width="100%">
                        <tr>
                            <th style="text-align: right;padding-right: 20px">Discount:</th>
                            <th style="text-align: right">
                                {!! Form::text("discount",0,["class"=>"form-control required","id"=>"discount","autocomplete"=>"off" , "onkeyup"=>"calc()", "style"=>"text-align: right"]) !!} 
                            </th>
                        </tr>
                        <tr>
                            <th style="text-align: right;padding-right: 20px">Total:</th>
                            <th style="text-align: right">$ {{number_format($total,2)}}</th>
                            {!! Form::hidden("total",$total,["class"=>"form-control required","id"=>"total","autocomplete"=>"off" ]) !!}
                        </tr>
                    </table>
                </div>
            @endif
        </div>
        <div class="col-md-5">
            <div class="form-group required" id="form-usd-error">
                {!! Form::label("usd","Paid amount",["class"=>"control-label"]) !!}
                {!! Form::text("paid",0,["class"=>"form-control required","id"=>"paid","autocomplete"=>"off", "onkeyup"=>"calc()","style"=>"text-align: right" ]) !!}
                <span id="usd-error" class="help-block"></span>
            </div>
            <div class="form-group required" id="form-usd-error">
                {!! Form::label("Due","Due amount",["class"=>"control-label"]) !!}
                {!! Form::text("due",0,["class"=>"form-control required","id"=>"due","autocomplete"=>"off","style"=>"text-align: right" ]) !!}
                
            </div>
            <div class="form-group required" id="form-usd-error">
                {!! Form::label("name","Customer Name",["class"=>"control-label"]) !!}
                {!! Form::text("name",0,["class"=>"form-control required","id"=>"name","autocomplete"=>"off" ]) !!}
                
            </div>
            <div class="form-group required" id="form-usd-error">
                {!! Form::label("phone","Customer phone",["class"=>"control-label"]) !!}
                {!! Form::text("phone",0,["class"=>"form-control required","id"=>"phone","autocomplete"=>"off" ]) !!}
                
            </div>
            <div class="form-group required" id="form-usd-error">
                {!! Form::label("address","Customer Address",["class"=>"control-label"]) !!}
                {!! Form::text("address",0,["class"=>"form-control required","id"=>"address","autocomplete"=>"off" ]) !!}
                
            </div>
        </div>
    </div>
</div>
<div class="modal-footer">
    <p id="msg" style="display: none;color: blue;float: left;">{{env('success_msg')}}</p>
    {!! Form::button("<i class='glyphicon glyphicon-remove'></i> Close",["class"=>"btn
    btn-primary","data-dismiss"=>"modal"])!!}
    {!! Form::button("<i class='glyphicon glyphicon-floppy-disk'></i> Save",["type" => "submit","class"=>"btn
    btn-primary","id"=>"btn_save"])!!}
</div>
<script type="text/javascript">
    function calc(){
        var discount= document.getElementById('discount').value;
        var total = document.getElementById('total').value;
        var paid = document.getElementById('paid').value;
        var due = document.getElementById('due').value;

        var adue=total -discount -paid ;
        document.getElementById('due').value= adue;        
    }
</script>