<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
    </button>
    <h4 class="modal-title">Select Table</h4>
</div>
<div class="modal-body">
    <div class="row">
        <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tbl <?php echo e($table->status); ?>"
                 onclick="ajaxLoad('cashier/select-table/<?php echo e($table->id); ?>','orderList');$('#modal').modal('hide');"><?php echo e($table->name); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH D:\mm\xampp\htdocs\POS\resources\views/cashier/table.blade.php ENDPATH**/ ?>