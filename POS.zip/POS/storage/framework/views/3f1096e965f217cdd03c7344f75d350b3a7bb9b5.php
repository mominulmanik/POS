<h2 class="page-header"><?php echo e(isset($table)?'Edit':'New'); ?> Table</h2>
<?php if(isset($table)): ?>
    <?php echo Form::model($table,["id"=>"frm","class"=>"form-horizontal","method"=>"put"]); ?>

<?php else: ?>
    <?php echo Form::open(["id"=>"frm","class"=>"form-horizontal"]); ?>

<?php endif; ?>
<div class="form-group required" id="form-name-error">
    <?php echo Form::label("name","Name",["class"=>"control-label col-md-2"]); ?>

    <div class="col-md-5">
        <?php echo Form::text("name",null,["class"=>"form-control required","id"=>"focus"]); ?>

        <span id="name-error" class="help-block"></span>
    </div>
</div>
<div class="form-group">
    <div class="col-md-5 col-md-push-2">
        <a href="javascript:ajaxLoad('table')" class="btn btn-danger"><i class="glyphicon glyphicon-backward"></i>
            Back</a>
        <?php echo Form::button("<i class='glyphicon glyphicon-floppy-disk'></i> Save",["type" => "submit","class"=>"btn
    btn-primary","id"=>"btn_save"]); ?>

    </div>
</div>
<?php echo Form::close(); ?><?php /**PATH D:\mm\xampp\htdocs\POS\resources\views/table/form.blade.php ENDPATH**/ ?>