<link href="<?php echo e(asset('bootstrap-3.3.7/css/bootstrap.min.css')); ?>" rel="stylesheet">
<div class="container-fluid">
    <h1 class="page-header">Product List </h1>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th width="80px" style="text-align: center"> Code</th>
            <th> Name</th>
            <th style="text-align: right">Unitprice</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="background: whitesmoke">
                <th colspan="3"><?php echo e($category->name); ?></th>
            </tr>
            <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td align="right">$ <?php echo e($product->unitprice); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH D:\mm\xampp\htdocs\POS\resources\views/product/print.blade.php ENDPATH**/ ?>