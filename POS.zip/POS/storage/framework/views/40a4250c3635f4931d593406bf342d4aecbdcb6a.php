<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
    </button>
    <h4 class="modal-title">View Order Detail</h4>
</div>
<div class="modal-body">
    <div class="row">
        <div class="col-md-5">
            <table class="table">
                <tr>
                    <th style="text-align: right;border-top: none">Invoice:</th>
                    <th style="border-top: none"><?php echo e(str_pad($order->id,6,0,0)); ?></th>
                </tr>
                <tr>
                    <th style="text-align: right;border-top: none">Table:</th>
                    <td style="border-top: none"><?php echo e($order->table->name); ?></td>
                </tr>
                <tr>
                    <th style="text-align: right;border-top: none">Checked in:</th>
                    <td style="border-top: none"><?php echo e(date('d-M-Y H:i',strtotime($order->checked_in))); ?></td>
                </tr>
                <tr>
                    <th style="text-align: right;border-top: none">Checked out:</th>
                    <td style="border-top: none"><?php echo e(date('d-M-Y H:i',strtotime($order->checked_out))); ?></td>
                </tr>
                <tr>
                    <th style="text-align: right;border-top: none">Cashier:</th>
                    <td style="border-top: none"><?php echo e($order->user?$order->user->username:''); ?></td>
                </tr>
                <tr>
                    <th style="text-align: right;border-top: none">Customer:</th>
                    <td style="border-top: none"><?php echo e($order->customer_id && $order->customer?$order->customer->name:''); ?></td>
                </tr>
                <tr>
                    <th style="text-align: right;border-top: none">Cash in:</th>
                    <td style="border-top: none">$ <?php echo e($order->usd); ?></td>
                </tr>
            </table>
        </div>
        <div class="col-md-7">
            <table class="table" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th width="50px" style="text-align: center">
                        No
                    </th>
                    <th> Description</th>
                    <th> Qty</th>
                    <th> U.Price</th>
                    <th> D.C</th>
                    <th> Total</th>
                </tr>
                </thead>
                <tbody>
                <?php $total = 0; $i = 1;?>
                <?php $__currentLoopData = $order->order_details()->withTrashed()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr <?php if(!empty($sale->deleted_at)): ?> style="text-decoration: line-through" <?php endif; ?>>
                        <td style="text-align: center"><?php echo e($i++); ?>

                        </td>
                        <td><?php echo e($sale->description); ?></td>
                        <td width="10px"><?php echo e($sale->quantity); ?></td>
                        <td align="right" width="40px">$ <?php echo e(number_format($sale->price,2)); ?></td>
                        <td align="center" width="30px"><?php echo e($sale->discount); ?></td>
                        <td align="right" width="70px">
                            $ <?php echo e(number_format($sale->quantity * $sale->price - $sale->discount,2)); ?></td>
                    </tr>
                    <?php if (empty($sale->deleted_at)) $total += ($sale->price * $sale->quantity - $sale->discount ); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div style="text-align: right;float: right;border-top: solid 1px whitesmoke;">
                <table width="100%">
                    <tr>
                        <th style="text-align: right;padding-right: 20px">Discount:</th>
                        <th style="text-align: right"><?php echo e($order->discount); ?> %</th>
                    </tr>
                    <tr>
                        <th style="text-align: right;padding-right: 20px">Total:</th>
                        <th style="text-align: right">$ <?php echo e(number_format($total-$order->discount,2)); ?></th>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\mm\xampp\htdocs\POS\resources\views/report/view.blade.php ENDPATH**/ ?>