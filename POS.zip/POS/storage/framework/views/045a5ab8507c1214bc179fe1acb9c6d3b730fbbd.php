<h1 class="page-header">Recipe</h1>
<div class="row">
    <div class="col-md-4 form-group">
        <?php echo Form::select('category',['-1'=>'Select Category']+App\ProductCategory::orderBy('name')->pluck('name','id')->toArray() ,Session::get('recipe_category'),['class'=>'form-control','style'=>'height:40px','onChange'=>'ajaxLoad("'.url("recipe").'?category="+this.value)']); ?>

    </div>
    <div class="col-md-6 form-group">
        <?php echo Form::select('product_id',$products ,Session::get('recipe_product_id'),['class'=>'form-control','style'=>'height:40px','onChange'=>'ajaxLoad("'.url("recipe").'?product_id="+this.value)']); ?>

    </div>
</div>
<?php if($product): ?>
    <b style="font-size: 14px;color: red"><?php echo e($product->name); ?></b>
    <div class="pull-right">
        <a href="javascript:ajaxLoad('recipe/create')" class="btn btn-primary btn-xs"><i
                    class="glyphicon glyphicon-plus-sign"></i> New</a>
    </div>

    <table class="table table-bordered table-striped" style="margin-top: 10px">
        <thead>
        <tr>
            <th width="50px" style="text-align: center">No</th>
            <th>Name</th>
            <th style="text-align: right">Quantity</th>
            <th style="text-align: center">Unit</th>
            <th width="140px"></th>
        </tr>
        </thead>
        <tbody>
        <?php $i = 1;?>
        <?php $__currentLoopData = $product->recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td align="center"><?php echo e($i++); ?></td>
                <td><?php echo e($recipe->item?$recipe->item->name:''); ?></td>
                <td align="right"><?php echo e($recipe->quantity); ?></td>
                <td align="center"><?php echo e($recipe->item?$recipe->item->unit:''); ?></td>
                <td style="text-align: center">
                    <a class="btn btn-primary btn-xs" title="Edit"
                       href="javascript:ajaxLoad('recipe/update/<?php echo e($recipe->id); ?>')">
                        <i class="glyphicon glyphicon-edit"></i> Edit</a>
                    <a class="btn btn-danger btn-xs" title="Delete"
                       href="javascript:if(confirm('Are you sure want to delete?')) ajaxDelete('recipe/delete/<?php echo e($recipe->id); ?>','<?php echo e(csrf_token()); ?>')">
                        <i class="glyphicon glyphicon-trash"></i> Delete
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?><?php /**PATH D:\mm\xampp\htdocs\POS\resources\views/recipe/index.blade.php ENDPATH**/ ?>