<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="margin-top: 10px">
        <div class="col-md-4" style="padding: 0px">
            <?php $__currentLoopData = $menuCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="menu <?php if($menuCategory->id==(Session::has('menuCategory_id')?Session::get('menuCategory_id'):env('DEFAULT_MENU_CATEGORY'))): ?> active  <?php endif; ?>"
                     onclick="$('.menu').removeClass('active');$(this).addClass('active');ajaxLoad('cashier/products?menuCategory_id=<?php echo e($menuCategory->id); ?>','productList')"><?php echo e($menuCategory->name); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-md-4">
            <input type="text" class="form-control"
                   style="border: 2px solid whitesmoke;height: 50px;border-radius: 0px;background: lightyellow;font-size: 18px"
                   onfocus="$(this).select()"
                   onkeyup="ajaxLoad('cashier/products?search='+this.value,'productList')"/>
            <div id="productList">
                <ul class="list-group"
                    style="height: 520px;overflow-y: auto;border: 2px outset;background: white">
                    <?php $__currentLoopData = \App\Product::where('product_category_id',Session::get('menuCategory_id'))->orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item"
                            style="font-size: 16px;padding:0px;height: 80px"
                            onclick="ajaxLoad('cashier/order/<?php echo e($menu->id); ?>','orderList')">
                            <img src="<?php echo e($menu->image!='' && File::exists('images/products/'.$menu->image)?'/images/products/'.$menu->image:'/images/default.jpg'); ?>"
                                 class="pull-left" width="80px" height="70px"
                                 style="margin: 5px 5px 0px 5px"/>
                            <div style="margin:20px">
                                <span style="color: red;font-size: 15px"
                                      class="pull-right">$<?php echo e(number_format($menu->unitprice,2)); ?></span>
                                <div><?php echo e($menu->name); ?> <span style="color: gray">(<?php echo e($menu->id); ?>)</span></div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="col-md-4" id="orderList">
            <?php echo $__env->make('cashier._order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cashier', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\POS\resources\views/cashier/index.blade.php ENDPATH**/ ?>