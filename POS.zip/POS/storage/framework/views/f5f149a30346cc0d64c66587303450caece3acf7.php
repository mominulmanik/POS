<center>
    <h1 style="font-size:20px;margin:0">SOURKEA RESTAURANT</h1>
    <h4 style="margin: 0">Daily Summary Report</h4>
    <h5 style="margin: 5px"><?php echo e(date('d-M-Y',strtotime(Session::get('report_from')))); ?></h5>
</center>
<hr style="size:2px;border:inset">
<h2 style="text-align: center;padding: 10px;background: whitesmoke">
    $ <?php echo e(number_format($orders['Total']['total'],2)); ?></h2>
<table style="width:100%;margin-top:10px" border="1px solid" cellspacing="0" cellpadding="5px">
    <tr style="font-size:14px">
        <th>Category</th>
        <th>Total</th>
    </tr>
    <?php $__currentLoopData = $sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($key!='Total'): ?>
            <tr style="font-size: 14px">
                <td><?php echo e($key); ?></td>
                <td align="right">$ <?php echo e(number_format($value['total'],2)); ?></td>
            </tr>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<table style="width:100%;margin-top:10px" border="1px solid" cellspacing="0" cellpadding="5px">
    <tr style="font-size:14px">
        <th>Period</th>
        <th>Total</th>
    </tr>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($key!='Total'): ?>
            <tr style="font-size: 14px">
                <td><?php echo e($key); ?></td>
                <td align="right">$ <?php echo e(number_format($value['total'],2)); ?></td>
            </tr>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
<script>
//    window.print();
//    window.close();
</script><?php /**PATH D:\mm\xampp\htdocs\POS\resources\views/report/print_daily_summary.blade.php ENDPATH**/ ?>