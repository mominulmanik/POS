<h2 class="page-header"><?php echo e(isset($item)?'Edit':'New'); ?> Item</h2>
<?php if(isset($item)): ?>
    <?php echo Form::model($item,["id"=>"frm","class"=>"form-horizontal","method"=>"put"]); ?>

<?php else: ?>
    <?php echo Form::open(["id"=>"frm","class"=>"form-horizontal"]); ?>

<?php endif; ?>
<div class="form-group required" id="form-name-error">
    <?php echo Form::label("name","Name",["class"=>"control-label col-md-2"]); ?>

    <div class="col-md-5">
        <?php echo Form::text("name",null,["class"=>"form-control required","id"=>"focus"]); ?>

        <span id="name-error" class="help-block"></span>
    </div>
</div>
<div class="form-group">
    <?php echo Form::label("item_category_id","Category",["class"=>"control-label col-md-2"]); ?>

    <div class="col-md-5">
        <?php echo Form::select("item_category_id",\App\ItemCategory::orderBy('name')->pluck('name','id'),null,["class"=>"form-control","style"=>"height:auto"]); ?>

    </div>
</div>
<div class="form-group required" id="form-unit-error">
    <?php echo Form::label("unit","Unit",["class"=>"control-label col-md-2"]); ?>

    <div class="col-md-5">
        <?php echo Form::text("unit",null,["class"=>"form-control required","id"=>"focus"]); ?>

        <span id="unit-error" class="help-block"></span>
    </div>
</div>
<div class="form-group">
    <div class="col-md-5 col-md-push-2">
        <a href="javascript:ajaxLoad('item')" class="btn btn-danger"><i class="glyphicon glyphicon-backward"></i>
            Back</a>
        <?php echo Form::button("<i class='glyphicon glyphicon-floppy-disk'></i> Save",["type" => "submit","class"=>"btn
    btn-primary","id"=>"btn_save"]); ?>

    </div>
</div>
<?php echo Form::close(); ?><?php /**PATH D:\mm\xampp\htdocs\POS\resources\views/item/form.blade.php ENDPATH**/ ?>