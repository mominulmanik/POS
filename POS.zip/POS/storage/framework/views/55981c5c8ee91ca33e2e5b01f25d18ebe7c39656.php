<h2 class="page-header"><?php echo e(isset($user)?'Edit':'New'); ?>User</h2>
<?php if(isset($user)): ?>
    <?php echo Form::model($user,["id"=>"frm","class"=>"form-horizontal","method"=>"put"]); ?>

<?php else: ?>
    <?php echo Form::open(["id"=>"frm","class"=>"form-horizontal"]); ?>

<?php endif; ?>
<div class="row">
    <div class="form-group required" id="form-username-error">
        <?php echo Form::label("username","Username",["class"=>"control-label col-md-2"]); ?>

        <div class="col-md-5">
            <?php echo Form::text("username",null,["class"=>"form-control required","id"=>"focus"]); ?>

            <span id="username-error" class="help-block"></span>
        </div>
    </div>
    <div class="form-group">
        <?php echo Form::label("role","Role",["class"=>"control-label col-md-2"]); ?>

        <div class="col-md-5">
            <?php echo Form::select("role",['Admin'=>'Admin','Cashier'=>'Cashier'],null,["class"=>"form-control"]); ?>

        </div>
    </div>
    <div class="form-group" id="form-password-error">
        <?php echo Form::label("password","Password",["class"=>"control-label col-md-2"]); ?>

        <div class="col-md-5">
            <?php echo Form::password("password",["class"=>"form-control required"]); ?>

            <span id="password-error" class="help-block"></span>
        </div>
    </div>
    <div class="form-group">
        <?php echo Form::label("password_confirmation","Confirm password",["class"=>"control-label col-md-2"]); ?>

        <div class="col-md-5">
            <?php echo Form::password("password_confirmation",["class"=>"form-control"]); ?>

        </div>
    </div>
    <div class="form-group">
        <?php echo Form::label("active","Active",["class"=>"control-label col-md-2"]); ?>

        <div class="col-md-5">
            <?php echo Form::checkbox("active",1,null,["style"=>"width:25px;height:25px"]); ?>

        </div>
    </div>
    <div class="form-group">
        <div class="col-md-5 col-md-push-2">
            <a href="javascript:ajaxLoad('<?php echo e(url('user')); ?>')"
               class="btn btn-danger"><i
                        class="glyphicon glyphicon-backward"></i> Back</a>
            <?php echo Form::button("<i class='glyphicon glyphicon-floppy-disk'></i> Save",["type" => "submit","class"=>"btn
        btn-primary","id"=>"btn_save"]); ?>

        </div>
    </div>
</div>
<?php echo Form::close(); ?><?php /**PATH D:\mm\xampp\htdocs\POS\resources\views/user/form.blade.php ENDPATH**/ ?>