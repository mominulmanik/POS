<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php echo e($order->quantity); ?>

<?php echo e($order->product_id); ?>

<?php echo e($order->p_quantity); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\xampp\htdocs\POS\resources\views/cashier/test.blade.php ENDPATH**/ ?>