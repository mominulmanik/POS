<h1 class="page-header">Stock Balance Report</h1>
<div class="col-md-3 form-group">
    <?php echo Form::select('category',['-1'=>'All Categories']+App\ItemCategory::orderBy('name')->pluck('name','id')->toArray() ,Session::get('item_category'),['class'=>'form-control','style'=>'height:auto','onChange'=>'ajaxLoad("'.url("report/stock-balance").'?category="+this.value)']); ?>

</div>
<div class="col-sm-4 form-group">
    <div class="input-group">
        <input class="form-control" id="search" value="<?php echo e(Session::get('item_search')); ?>"
               onkeydown="if (event.keyCode == 13) ajaxLoad('<?php echo e(url('report/stock-balance')); ?>?ok=1&search='+this.value)"
               placeholder="Search..."
               type="text">

        <div class="input-group-btn">
            <button type="button" class="btn btn-default"
                    onclick="ajaxLoad('<?php echo e(url('report/stock-balance')); ?>?ok=1&search='+$('#search').val())"><i
                        class="glyphicon glyphicon-search"></i>
            </button>
        </div>
    </div>
</div>
<table class="table table-bordered table-striped">
    <thead>
    <tr>
        <th width="50px" style="text-align: center">No</th>
        <th>
            <a href="javascript:ajaxLoad('report/stock-balance?field=name&sort=<?php echo e(Session::get("item_sort")=="asc"?"desc":"asc"); ?>')">
                Name
            </a>
            <i style="font-size: 12px"
               class="glyphicon  <?php echo e(Session::get('item_field')=='name'?(Session::get('item_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
            </i>
        </th>
        <th>Category</th>
        <th style="text-align: center">Unit</th>
        <th style="text-align: center">Quantity</th>
    </tr>
    </thead>
    <tbody>
    <?php $i = 1;?>
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td align="center"><?php echo e($i++); ?></td>
            <td><?php echo e($item->name); ?></td>
            <td><?php echo e($item->item_category_id?$item->item_category->name:''); ?></td>
            <td align="center"><?php echo e($item->unit); ?></td>
            <td style="text-align: center">
                <?php echo e($item->quantity); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="pull-right"><?php echo str_replace('/?','?',$items->render()); ?></div>
<div class="row">
    <i class="col-sm-12">
        Total: <?php echo e($items->total()); ?> records
    </i>
</div><?php /**PATH D:\mm\xampp\htdocs\POS\resources\views/report/stock_balance.blade.php ENDPATH**/ ?>