<h2 class="page-header"><?php echo e(isset($customer)?'Edit':'New'); ?> Customer</h2>
<?php if(isset($customer)): ?>
    <?php echo Form::model($customer,["id"=>"frm","class"=>"form-horizontal","method"=>"put"]); ?>

<?php else: ?>
    <?php echo Form::open(["id"=>"frm","class"=>"form-horizontal"]); ?>

<?php endif; ?>
<div class="form-group required" id="form-name-error">
    <?php echo Form::label("name","Name",["class"=>"control-label col-md-2"]); ?>

    <div class="col-md-5">
        <?php echo Form::text("name",null,["class"=>"form-control required","id"=>"focus"]); ?>

        <span id="name-error" class="help-block"></span>
    </div>
</div>
<div class="form-group required" id="form-discount-error">
    <?php echo Form::label("discount","Discount",["class"=>"control-label col-md-2"]); ?>

    <div class="col-md-5">
        <?php echo Form::text("discount",null,["class"=>"form-control required"]); ?>

        <span id="discount-error" class="help-block"></span>
    </div>
</div>
<div class="form-group">
    <div class="col-md-5 col-md-push-2">
        <a href="javascript:ajaxLoad('customer')" class="btn btn-danger"><i class="glyphicon glyphicon-backward"></i>
            Back</a>
        <?php echo Form::button("<i class='glyphicon glyphicon-floppy-disk'></i> Save",["type" => "submit","class"=>"btn
    btn-primary","id"=>"btn_save"]); ?>

    </div>
</div>
<?php echo Form::close(); ?><?php /**PATH D:\mm\xampp\htdocs\POS\resources\views/customer/form.blade.php ENDPATH**/ ?>